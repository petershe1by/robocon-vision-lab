算法输入：image.png + camera_info.json。
points.json（如有）为人工点选的单面角点。
长度单位m；光学坐标X右、Y下、Z前。
image.png不含UI选中框和点选标记。
这是理想针孔渲染样本，不代表实拍精度。
若附ground_truth.json，它仅用于独立误差核对，不应作为识别器输入。